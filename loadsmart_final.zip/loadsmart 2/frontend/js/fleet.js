// Автопарк: карточки машин с иллюстрациями, характеристики, добавление и удаление.

const VTYPE_RU = {
  gazelle: 'Газель (тент)',
  gazelle_next: 'Газель Next (фургон)',
  refrigerator: 'Рефрижератор',
  truck: 'Фура (еврофургон)',
};

// Векторная side-view иллюстрация машины по типу (без внешних картинок, работает офлайн).
function vehicleSVG(type) {
  const C = {
    body: '#2b3441', stroke: '#475264', cab: '#ff7a18', cabStroke: '#c85e0e',
    glass: '#9fd0ff', wheel: '#0e1116', hub: '#5b6673', accent: '#ffb454',
  };
  const wheel = (cx) =>
    `<circle cx="${cx}" cy="74" r="11" fill="${C.wheel}"/><circle cx="${cx}" cy="74" r="4.5" fill="${C.hub}"/>`;

  if (type === 'truck') {
    return `<svg viewBox="0 0 240 90" xmlns="http://www.w3.org/2000/svg">
      <rect x="58" y="14" width="166" height="52" rx="4" fill="${C.body}" stroke="${C.stroke}" stroke-width="2"/>
      <line x1="58" y1="40" x2="224" y2="40" stroke="${C.stroke}" stroke-width="1.5"/>
      <path d="M16 66 V40 q0-8 8-8 h26 l8 14 v20 Z" fill="${C.cab}" stroke="${C.cabStroke}" stroke-width="2"/>
      <path d="M28 38 h18 l5 9 h-23 Z" fill="${C.glass}"/>
      <rect x="14" y="58" width="6" height="6" fill="${C.accent}"/>
      ${wheel(34)}${wheel(150)}${wheel(186)}
    </svg>`;
  }
  if (type === 'refrigerator') {
    return `<svg viewBox="0 0 220 90" xmlns="http://www.w3.org/2000/svg">
      <rect x="54" y="20" width="150" height="46" rx="4" fill="#e8eef5" stroke="${C.stroke}" stroke-width="2"/>
      <rect x="60" y="10" width="40" height="12" rx="3" fill="${C.stroke}"/>
      <text x="130" y="48" font-size="13" fill="#5b6673" font-family="monospace">❄</text>
      <path d="M14 66 V40 q0-8 8-8 h24 l8 14 v20 Z" fill="${C.cab}" stroke="${C.cabStroke}" stroke-width="2"/>
      <path d="M26 38 h16 l5 9 h-21 Z" fill="${C.glass}"/>
      ${wheel(32)}${wheel(150)}${wheel(182)}
    </svg>`;
  }
  // gazelle / gazelle_next — компактный фургон
  const box = type === 'gazelle_next' ? 130 : 110;
  const rearWheel = 64 + box - 30;
  return `<svg viewBox="0 0 200 90" xmlns="http://www.w3.org/2000/svg">
    <rect x="64" y="22" width="${box}" height="44" rx="4" fill="${C.body}" stroke="${C.stroke}" stroke-width="2"/>
    <path d="M18 66 V42 q0-10 10-10 h28 q8 0 8 8 v26 Z" fill="${C.cab}" stroke="${C.cabStroke}" stroke-width="2"/>
    <path d="M30 40 h20 q4 0 4 4 v6 h-28 Z" fill="${C.glass}"/>
    <rect x="16" y="58" width="6" height="6" fill="${C.accent}"/>
    ${wheel(40)}${wheel(rearWheel)}
  </svg>`;
}

function loadBarColor(pct) {
  if (pct > 90) return 'var(--red)';
  if (pct > 65) return 'var(--yellow)';
  return 'var(--green)';
}

async function renderFleet() {
  const host = document.getElementById('fleetHost');
  host.innerHTML = `<div class="state"><div class="spinner"></div>Загрузка автопарка…</div>`;
  let vs;
  try {
    vs = await getVehicles();
  } catch (e) {
    host.innerHTML = `<div class="state error">Не удалось загрузить автопарк. Проверьте сервер.</div>`;
    return;
  }
  if (!vs.length) {
    host.innerHTML = `<div class="state">В автопарке пока нет машин. Добавьте первую →</div>`;
    return;
  }

  const cnt = document.getElementById('fleetCount');
  if (cnt) cnt.textContent = `${vs.length} машин`;

  host.innerHTML = vs.map(v => {
    const statusBadge = v.is_available
      ? `<span class="badge st-delivered">🟢 Свободна</span>`
      : `<span class="badge st-cancelled">🔴 Занята</span>`;
    return `
    <div class="fleet-card">
      <div class="fleet-illustration">${vehicleSVG(v.type)}</div>
      <div class="fleet-head">
        <div>
          <h3>${v.name}</h3>
          <span class="fleet-type">${VTYPE_RU[v.type] || v.type}</span>
        </div>
        ${statusBadge}
      </div>
      <p class="fleet-desc">${v.description || '—'}</p>
      <div class="fleet-specs">
        <div><span>Габариты Д×Ш×В</span><b>${v.length_m}×${v.width_m}×${v.height_m} м</b></div>
        <div><span>Объём кузова</span><b>${v.volume_m3} м³</b></div>
        <div><span>Грузоподъёмность</span><b>${(v.max_weight_kg / 1000).toFixed(1)} т</b></div>
        <div><span>Осей</span><b>${v.axles}</b></div>
      </div>
      <div class="fleet-load">
        <div class="fl-row"><span>Объём ${v.load_pct}%</span>
          <div class="mini-bar"><i style="width:${Math.min(v.load_pct, 100)}%;background:${loadBarColor(v.load_pct)}"></i></div>
        </div>
        <div class="fl-row"><span>Масса ${v.weight_pct}%</span>
          <div class="mini-bar"><i style="width:${Math.min(v.weight_pct, 100)}%;background:${loadBarColor(v.weight_pct)}"></i></div>
        </div>
        <div class="fl-orders">Заказов: ${v.orders_count} · занято ${v.used_volume_m3} м³ / ${Math.round(v.used_weight_kg)} кг</div>
      </div>
      <div class="fleet-actions">
        <button class="btn-primary" onclick="openInPlanner(${v.id})">Открыть в 3D</button>
        <button class="icon-btn danger" title="Удалить" onclick="removeVehicle(${v.id}, '${v.name.replace(/'/g, '')}')">🗑</button>
      </div>
    </div>`;
  }).join('');
}

function openInPlanner(vehicleId) {
  window.showTab('planner');
  setTimeout(() => {
    const sel = document.getElementById('vehicleSelect');
    if (sel) { sel.value = String(vehicleId); sel.dispatchEvent(new Event('change')); }
  }, 120);
}

async function removeVehicle(id, name) {
  if (!confirm(`Удалить машину «${name}» из автопарка?\nЕё активные заказы вернутся в статус «Новый».`)) return;
  try {
    const res = await deleteVehicle(id);
    toast(res.released_orders
      ? `Машина удалена, освобождено заказов: ${res.released_orders}`
      : 'Машина удалена');
    renderFleet();
  } catch (e) {
    toast('Не удалось удалить: ' + e.message, true);
  }
}

// ---------- добавление машины ----------
function openAddVehicle() {
  document.getElementById('vehicleModal').classList.add('open');
  updateVolumePreview();
}
function closeAddVehicle() { document.getElementById('vehicleModal').classList.remove('open'); }

function updateVolumePreview() {
  const f = document.getElementById('vehicleForm');
  if (!f) return;
  const l = Number(f.length_m.value) || 0;
  const w = Number(f.width_m.value) || 0;
  const h = Number(f.height_m.value) || 0;
  document.getElementById('volPreview').textContent = (l * w * h).toFixed(1) + ' м³';
}

async function submitVehicle(ev) {
  ev.preventDefault();
  const f = ev.target;
  const payload = {
    name: f.name.value.trim(),
    type: f.type.value,
    length_m: Number(f.length_m.value),
    width_m: Number(f.width_m.value),
    height_m: Number(f.height_m.value),
    max_weight_kg: Number(f.max_weight_kg.value),
    axles: Number(f.axles.value),
    description: f.description.value.trim(),
  };
  try {
    await createVehicle(payload);
    closeAddVehicle();
    f.reset();
    toast(`Машина «${payload.name}» добавлена в автопарк`);
    renderFleet();
  } catch (e) {
    toast('Не удалось добавить: ' + e.message, true);
  }
}

Object.assign(window, {
  renderFleet, openInPlanner, removeVehicle,
  openAddVehicle, closeAddVehicle, submitVehicle, updateVolumePreview,
});
