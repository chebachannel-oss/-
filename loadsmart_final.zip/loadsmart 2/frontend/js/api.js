// Все обращения к серверу — только здесь. Поменяется порт — правим одну строку.
const BASE_URL = 'http://localhost:8000';

async function _json(r) {
  if (!r.ok) {
    let detail = 'HTTP ' + r.status;
    try { const j = await r.json(); if (j.detail) detail = j.detail; } catch (e) {}
    throw new Error(detail);
  }
  return r.json();
}

async function getVehicles() {
  return _json(await fetch(`${BASE_URL}/api/vehicles`));
}

async function createVehicle(payload) {
  return _json(await fetch(`${BASE_URL}/api/vehicles`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }));
}

async function deleteVehicle(id) {
  return _json(await fetch(`${BASE_URL}/api/vehicles/${id}`, { method: 'DELETE' }));
}

async function getOrders(filters = {}) {
  const clean = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
  const params = new URLSearchParams(clean);
  return _json(await fetch(`${BASE_URL}/api/orders?${params}`));
}

async function getLoadPlan(vehicleId) {
  return _json(await fetch(`${BASE_URL}/api/load-plan?vehicle_id=${vehicleId}`));
}

async function getAnalytics() {
  return _json(await fetch(`${BASE_URL}/api/analytics`));
}

async function getStats() {
  return _json(await fetch(`${BASE_URL}/api/stats`));
}

async function updateOrderStatus(orderId, status) {
  return _json(await fetch(`${BASE_URL}/api/orders/${orderId}/status`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  }));
}

async function createOrder(payload) {
  return _json(await fetch(`${BASE_URL}/api/orders`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }));
}

async function assignOrder(orderId) {
  return _json(await fetch(`${BASE_URL}/api/orders/${orderId}/assign`, { method: 'POST' }));
}

Object.assign(window, {
  BASE_URL, getVehicles, createVehicle, deleteVehicle, getOrders, getLoadPlan,
  getAnalytics, getStats, updateOrderStatus, createOrder, assignOrder,
});
