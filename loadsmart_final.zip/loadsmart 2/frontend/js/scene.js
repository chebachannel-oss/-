// 3D-планировщик загрузки: реалистичная модель машины + палеты.
// ES-модуль: Three.js r158 + OrbitControls.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const CARGO_RU = { standard: 'Стандартный', fragile: 'Хрупкий', oversize: 'Негабаритный' };

let renderer, scene, camera, controls;
let truckGroup, palletGroup, cogGroup;
let raycaster, pointer;
let selected = null, selectedBase = null;
let currentPlan = null, currentVehicle = null;
let heatmap = false;
const ordersById = {};
const hostId = 'sceneHost';
let maxPalletWeight = 1;

async function initPlanner() {
  const host = document.getElementById(hostId);

  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(host.clientWidth, host.clientHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  host.appendChild(renderer.domElement);

  scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x10141a, 28, 70);

  camera = new THREE.PerspectiveCamera(50, host.clientWidth / host.clientHeight, 0.1, 300);
  camera.position.set(10, 8, 12);

  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.maxPolarAngle = Math.PI * 0.49;   // не уходить под пол
  controls.minDistance = 3;
  controls.maxDistance = 60;

  // свет
  scene.add(new THREE.HemisphereLight(0xbcd0e8, 0x1a1f26, 0.8));
  const key = new THREE.DirectionalLight(0xffffff, 1.6);
  key.position.set(10, 18, 8);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.near = 1;
  key.shadow.camera.far = 80;
  const d = 22;
  Object.assign(key.shadow.camera, { left: -d, right: d, top: d, bottom: -d });
  key.shadow.bias = -0.0004;
  scene.add(key);
  const fill = new THREE.DirectionalLight(0xff9a4d, 0.35);
  fill.position.set(-10, 6, -8);
  scene.add(fill);

  // склад: «земля» на уровне нижней точки колёс (-1.0), чтобы кузов и колёса было видно
  const GROUND_Y = -1.0;
  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(80, 64),
    new THREE.MeshStandardMaterial({ color: 0x12161c, roughness: 1 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = GROUND_Y;
  ground.receiveShadow = true;
  scene.add(ground);

  const grid = new THREE.GridHelper(80, 80, 0x2a3340, 0x1d242d);
  grid.position.y = GROUND_Y + 0.001;
  scene.add(grid);
  window._groundY = GROUND_Y;

  truckGroup = new THREE.Group();
  palletGroup = new THREE.Group();
  cogGroup = new THREE.Group();
  scene.add(truckGroup, palletGroup, cogGroup);

  raycaster = new THREE.Raycaster();
  pointer = new THREE.Vector2();

  renderer.domElement.addEventListener('mousemove', onHover);
  renderer.domElement.addEventListener('click', onClick);
  window.addEventListener('resize', onResize);

  bindMoveSliders();
  animate();
  await refreshVehicleList();
}

async function refreshVehicleList() {
  const sel = document.getElementById('vehicleSelect');
  const msg = document.getElementById('planMsg');
  try {
    const vehicles = await getVehicles();
    sel.innerHTML = '<option value="">— выберите машину —</option>' +
      vehicles.map(v => {
        const icon = v.is_available ? '🟢' : '🔴';
        return `<option value="${v.id}">${icon} ${v.name} · ${v.load_pct}%</option>`;
      }).join('');
    sel.onchange = () => { if (sel.value) loadAndRender(Number(sel.value)); };
    if (msg && !sel.value) msg.textContent = 'Выберите машину для расчёта загрузки';

    const orders = await getOrders();
    orders.forEach(o => (ordersById[o.id] = o));
    return true;
  } catch (e) {
    if (sel) sel.innerHTML = '<option value="">— сервер недоступен —</option>';
    if (msg) msg.textContent = 'Сервер недоступен. Нажмите «Рассчитать загрузку» когда сервер поднимется.';
    return false;
  }
}

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  if (cogGroup.children[0]) {
    cogGroup.children[0].rotation.y += 0.02;
  }
  renderer.render(scene, camera);
}

function onResize() {
  if (!renderer) return;
  const host = document.getElementById(hostId);
  renderer.setSize(host.clientWidth, host.clientHeight);
  camera.aspect = host.clientWidth / host.clientHeight;
  camera.updateProjectionMatrix();
}

async function loadAndRender(vehicleId) {
  const msg = document.getElementById('planMsg');
  msg.style.display = 'grid';
  msg.textContent = 'Расчёт укладки…';
  let plan;
  try {
    plan = await getLoadPlan(vehicleId);
  } catch (e) {
    msg.textContent = 'Не удалось загрузить данные. Проверьте подключение к серверу.';
    return;
  }
  msg.style.display = 'none';
  currentPlan = plan;
  currentVehicle = plan.vehicle;
  maxPalletWeight = Math.max(1, ...plan.pallets.map(p => p.weight_kg));
  buildTruck(plan.vehicle);
  drawPallets(plan.pallets);
  drawCoG(plan);
  updatePanel(plan);
  deselect();
}

// ---------------- модель машины ----------------
function clearGroup(group) {
  while (group.children.length) {
    const c = group.children.pop();
    c.traverse?.(o => { o.geometry?.dispose?.(); o.material?.dispose?.(); });
    c.geometry?.dispose?.();
    c.material?.dispose?.();
    group.remove(c);
  }
}

function makeWheel(r, x, z) {
  const w = new THREE.Mesh(
    new THREE.CylinderGeometry(r, r, 0.32, 22),
    new THREE.MeshStandardMaterial({ color: 0x0e1116, roughness: 0.85 })
  );
  w.rotation.z = Math.PI / 2;
  w.position.set(x, r, z);
  w.castShadow = true;
  return w;
}

function buildTruck(v) {
  clearGroup(truckGroup);
  const { width_m: W, height_m: H, length_m: L, type } = v;
  const wall = 0.05;

  // === грузовой отсек: пол + 3 стенки + крыша-каркас ===
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x39424e, roughness: 0.9 });
  const floor = new THREE.Mesh(new THREE.BoxGeometry(W + wall, wall, L + wall), floorMat);
  floor.position.set(W / 2, -wall / 2, L / 2);
  floor.receiveShadow = true;
  truckGroup.add(floor);

  const panelMat = new THREE.MeshStandardMaterial({
    color: 0x9fb2c4, roughness: 0.5, metalness: 0.2,
    transparent: true, opacity: 0.16, side: THREE.DoubleSide,
  });
  // левая, правая, передняя стенки
  const left = new THREE.Mesh(new THREE.BoxGeometry(wall, H, L), panelMat);
  left.position.set(0, H / 2, L / 2);
  const right = left.clone(); right.position.x = W;
  const front = new THREE.Mesh(new THREE.BoxGeometry(W, H, wall), panelMat);
  front.position.set(W / 2, H / 2, 0);
  truckGroup.add(left, right, front);

  // каркас рёбер кузова
  const edges = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(W, H, L)),
    new THREE.LineBasicMaterial({ color: 0xff7a18, transparent: true, opacity: 0.85 })
  );
  edges.position.set(W / 2, H / 2, L / 2);
  truckGroup.add(edges);

  // === кабина (спереди, со стороны z=0) ===
  const cabLen = type === 'truck' ? 1.9 : 1.4;
  const cabMat = new THREE.MeshStandardMaterial({ color: 0xe0e6ee, roughness: 0.4, metalness: 0.3 });
  const cab = new THREE.Mesh(new THREE.BoxGeometry(W * 0.96, H * 0.82, cabLen), cabMat);
  cab.position.set(W / 2, H * 0.41, -cabLen / 2 - 0.05);
  cab.castShadow = true;
  truckGroup.add(cab);
  // лобовое стекло
  const glass = new THREE.Mesh(
    new THREE.BoxGeometry(W * 0.8, H * 0.34, 0.06),
    new THREE.MeshStandardMaterial({ color: 0x2b3a4a, roughness: 0.1, metalness: 0.6 })
  );
  glass.position.set(W / 2, H * 0.58, -cabLen - 0.06);
  truckGroup.add(glass);
  // фары
  [-W * 0.32, W * 0.32].forEach(dx => {
    const lamp = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.12, 0.05),
      new THREE.MeshStandardMaterial({ color: 0xfff2c0, emissive: 0xffcc55, emissiveIntensity: 0.6 })
    );
    lamp.position.set(W / 2 + dx, H * 0.2, -cabLen - 0.08);
    truckGroup.add(lamp);
  });

  // === колёса ===
  const r = type === 'truck' ? 0.5 : 0.38;
  const wheels = [];
  const inset = 0.0;
  // передние (под кабиной)
  wheels.push(makeWheel(r, inset, -cabLen * 0.5));
  wheels.push(makeWheel(r, W - inset, -cabLen * 0.5));
  // задние оси
  const rearZ = type === 'truck' ? [L * 0.78, L * 0.9] : [L * 0.82];
  rearZ.forEach(z => {
    wheels.push(makeWheel(r, inset, z));
    wheels.push(makeWheel(r, W - inset, z));
  });
  wheels.forEach(w => truckGroup.add(w));

  // подложка-площадка под машину
  const pad = new THREE.Mesh(
    new THREE.PlaneGeometry(W + 2.4, L + cabLen + 2.4),
    new THREE.MeshStandardMaterial({ color: 0x1b2129, roughness: 1 })
  );
  pad.rotation.x = -Math.PI / 2;
  pad.position.set(W / 2, 0.001, (L - cabLen) / 2);
  pad.receiveShadow = true;
  truckGroup.add(pad);

  // камера на кузов
  controls.target.set(W / 2, H / 2, L / 2);
  const rr = Math.max(W, H, L);
  camera.position.set(W / 2 + rr * 0.9, H + rr * 0.7, L + rr * 0.5);
  controls.update();
}

// ---------------- палеты ----------------
function palletColor(p) {
  if (heatmap) {
    const t = Math.min(p.weight_kg / maxPalletWeight, 1);
    // зелёный -> жёлтый -> красный
    const c = new THREE.Color();
    c.setHSL((1 - t) * 0.33, 0.85, 0.5);
    return c;
  }
  return new THREE.Color(p.color);
}

function drawPallets(pallets) {
  clearGroup(palletGroup);
  pallets.forEach((p, i) => {
    const grp = new THREE.Group();

    // деревянный поддон снизу
    const skid = new THREE.Mesh(
      new THREE.BoxGeometry(p.width, 0.12, p.depth),
      new THREE.MeshStandardMaterial({ color: 0x8a5a2b, roughness: 0.95 })
    );
    skid.position.y = -p.height / 2 + 0.06;
    skid.castShadow = true; skid.receiveShadow = true;
    grp.add(skid);

    // груз
    const bodyH = Math.max(0.05, p.height - 0.12);
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(p.width - 0.04, bodyH, p.depth - 0.04),
      new THREE.MeshStandardMaterial({ color: palletColor(p), roughness: 0.55, metalness: 0.08 })
    );
    body.position.y = 0.06;
    body.castShadow = true; body.receiveShadow = true;
    grp.add(body);

    // обводка
    const wire = new THREE.LineSegments(
      new THREE.EdgesGeometry(body.geometry),
      new THREE.LineBasicMaterial({ color: 0x0b0e12, transparent: true, opacity: 0.35 })
    );
    wire.position.copy(body.position);
    grp.add(wire);

    // маркер «хрупкое»
    if (p.fragile) {
      const mark = new THREE.Mesh(
        new THREE.SphereGeometry(0.07, 12, 12),
        new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xff5555, emissiveIntensity: 0.5 })
      );
      mark.position.set(0, bodyH / 2 + 0.08, 0);
      grp.add(mark);
    }

    grp.position.set(p.x, p.y, p.z);
    grp.userData = p;
    grp.children.forEach(c => (c.userData = p));
    palletGroup.add(grp);

    // анимация появления (drop-in)
    const targetY = p.y;
    grp.position.y = p.y + 4 + i * 0.02;
    grp.scale.setScalar(0.9);
    const start = performance.now() + i * 18;
    function drop(t) {
      const k = Math.min(Math.max((t - start) / 360, 0), 1);
      const ease = 1 - Math.pow(1 - k, 3);
      grp.position.y = (p.y + 4) + (targetY - (p.y + 4)) * ease;
      grp.scale.setScalar(0.9 + 0.1 * ease);
      if (k < 1) requestAnimationFrame(drop);
    }
    requestAnimationFrame(drop);
  });
}

function drawCoG(plan) {
  clearGroup(cogGroup);
  if (!plan.pallet_count) return;
  const g = plan.center_of_gravity;
  // маркер центра тяжести
  const marker = new THREE.Group();
  const ball = new THREE.Mesh(
    new THREE.SphereGeometry(0.13, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0x00e5ff, emissive: 0x00aaff, emissiveIntensity: 0.7 })
  );
  marker.add(ball);
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(0.26, 0.02, 8, 32),
    new THREE.MeshStandardMaterial({ color: 0x00e5ff, emissive: 0x00aaff, emissiveIntensity: 0.5 })
  );
  ring.rotation.x = Math.PI / 2;
  marker.add(ring);
  marker.position.set(g.x, g.y, g.z);
  cogGroup.add(marker);

  // вертикальная линия проекции ЦТ на пол
  const lineGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(g.x, 0, g.z), new THREE.Vector3(g.x, g.y, g.z),
  ]);
  cogGroup.add(new THREE.Line(lineGeo,
    new THREE.LineBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0.5 })));
}

// ---------------- панель метрик ----------------
function setBar(id, pct) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.width = Math.min(pct, 100) + '%';
  el.style.background = pct > 90
    ? 'linear-gradient(90deg,#ef4444,#f87171)'
    : pct > 65 ? 'linear-gradient(90deg,#f59e0b,#fbbf24)'
    : 'linear-gradient(90deg,#ff7a18,#ffb454)';
}

function updatePanel(plan) {
  const v = plan.vehicle;
  document.getElementById('fillPct').textContent = plan.fill_pct + '%';
  setBar('fillBar', plan.fill_pct);
  setBar('weightBar', plan.weight_pct);

  document.getElementById('fillVolume').textContent =
    `${plan.used_volume_m3} / ${v.volume_m3} м³`;
  document.getElementById('fillWeightVal').textContent =
    `${Math.round(plan.total_weight_kg)} / ${Math.round(v.max_weight_kg)} кг`;
  document.getElementById('weightPct').textContent = plan.weight_pct + '%';

  document.getElementById('mPallets').textContent =
    plan.pallet_count + (plan.unplaced_count ? ` (+${plan.unplaced_count} не влезло)` : '');
  document.getElementById('mLayers').textContent = plan.layers;
  document.getElementById('mStability').textContent = plan.stability_pct + '%';

  const ax = plan.axle_load;
  document.getElementById('axFront').textContent = `${ax.front_kg} кг`;
  document.getElementById('axRear').textContent = `${ax.rear_kg} кг`;
  document.getElementById('axFrontBar').style.height = ax.front_pct + '%';
  document.getElementById('axRearBar').style.height = ax.rear_pct + '%';

  // цвет индикатора устойчивости
  const stEl = document.getElementById('mStability');
  stEl.style.color = plan.stability_pct >= 70 ? '#22c55e'
    : plan.stability_pct >= 50 ? '#f59e0b' : '#ef4444';

  // предупреждение о перегрузе
  const warn = document.getElementById('planWarn');
  const msgs = [];
  if (plan.weight_pct > 100) msgs.push('⚠️ Перегруз по массе');
  if (plan.unplaced_count) msgs.push(`⚠️ ${plan.unplaced_count} палет не помещается`);
  if (plan.stability_pct < 50) msgs.push('⚠️ Низкая устойчивость');
  warn.innerHTML = msgs.join('<br>');
  warn.style.display = msgs.length ? 'block' : 'none';
}

// ---------------- наведение / подсказка ----------------
function setPointer(ev) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
  return rect;
}

function pickPallet() {
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects(palletGroup.children, true);
  if (!hits.length) return null;
  let o = hits[0].object;
  while (o.parent && o.parent !== palletGroup) o = o.parent;
  return o;
}

function onHover(ev) {
  const rect = setPointer(ev);
  const mesh = pickPallet();
  const tip = document.getElementById('tooltip');
  if (!mesh) { tip.style.display = 'none'; return; }
  const p = mesh.userData;
  const order = ordersById[p.order_id] || {};
  tip.innerHTML =
    `<b>Заказ #${p.order_id}</b><br>` +
    `Ярус: ${p.layer + 1}${p.rotated ? ' · повёрнута' : ''}<br>` +
    `Тип: ${CARGO_RU[p.cargo_type] || p.cargo_type}<br>` +
    `Вес: ${p.weight_kg} кг · ${p.volume_m3} м³<br>` +
    `Получатель: ${order.recipient || '—'}`;
  tip.style.display = 'block';
  tip.style.left = (ev.clientX - rect.left + 14) + 'px';
  tip.style.top = (ev.clientY - rect.top + 14) + 'px';
}

function onClick(ev) {
  setPointer(ev);
  const mesh = pickPallet();
  if (!mesh) { deselect(); return; }
  select(mesh);
}

function bodyOf(grp) { return grp.children.find(c => c.geometry?.type === 'BoxGeometry' && c.position.y >= 0); }

function select(mesh) {
  deselect();
  selected = mesh;
  selectedBase = mesh.position.clone();
  const body = bodyOf(mesh);
  if (body) { body.material.emissive = new THREE.Color(0xff7a18); body.material.emissiveIntensity = 0.7; }
  document.getElementById('movePanel').style.display = 'flex';
  document.getElementById('moveTitle').textContent = `#${mesh.userData.order_id}`;
  ['moveX', 'moveY', 'moveZ'].forEach(id => { const el = document.getElementById(id); if (el) el.value = 0; });
}

function deselect() {
  if (selected) {
    const body = bodyOf(selected);
    if (body) { body.material.emissive = new THREE.Color(0x000000); body.material.emissiveIntensity = 0; }
  }
  selected = null; selectedBase = null;
  document.getElementById('movePanel').style.display = 'none';
}

function bindMoveSliders() {
  const apply = () => {
    if (!selected || !selectedBase) return;
    const dx = Number(document.getElementById('moveX').value);
    const dz = Number(document.getElementById('moveZ').value);
    const dy = Number((document.getElementById('moveY') || {}).value || 0);
    selected.position.x = selectedBase.x + dx;
    selected.position.z = selectedBase.z + dz;
    selected.position.y = Math.max(selected.userData.height / 2, selectedBase.y + dy);
  };
  ['moveX', 'moveY', 'moveZ'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', apply);
  });
}

// ---------------- виды камеры ----------------
function setView(which) {
  if (!currentVehicle) return;
  const { width_m: W, height_m: H, length_m: L } = currentVehicle;
  const r = Math.max(W, H, L);
  controls.target.set(W / 2, H / 2, L / 2);
  if (which === 'top') camera.position.set(W / 2, r * 1.8, L / 2 + 0.001);
  else if (which === 'side') camera.position.set(W / 2 + r * 1.6, H / 2, L / 2);
  else if (which === 'rear') camera.position.set(W / 2, H * 0.8, L + r);
  else camera.position.set(W / 2 + r * 0.9, H + r * 0.7, L + r * 0.5);
  controls.update();
}

function toggleHeatmap() {
  heatmap = !heatmap;
  document.getElementById('heatBtn').classList.toggle('active', heatmap);
  if (currentPlan) drawPallets(currentPlan.pallets);
}

// ---------------- выгрузка ----------------
function exportScene() {
  if (!renderer) return;
  renderer.render(scene, camera);
  const img = renderer.domElement.toDataURL('image/png');
  const name = currentVehicle ? currentVehicle.name : 'схема';
  const p = currentPlan || {};
  const html =
    `<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8">` +
    `<title>LoadSmart — ${name}</title>` +
    `<style>body{background:#14171c;color:#e6e9ee;font-family:sans-serif;text-align:center;padding:24px}` +
    `img{max-width:100%;border:1px solid #2e3742;border-radius:8px}` +
    `.m{display:inline-block;margin:6px 14px;color:#8a96a5}</style></head><body>` +
    `<h2>LoadSmart · ${name}</h2>` +
    `<p><span class="m">Объём: ${p.fill_pct ?? '—'}%</span>` +
    `<span class="m">Масса: ${p.weight_pct ?? '—'}%</span>` +
    `<span class="m">Палет: ${p.pallet_count ?? '—'}</span>` +
    `<span class="m">Устойчивость: ${p.stability_pct ?? '—'}%</span>` +
    `<span class="m">${new Date().toLocaleString('ru-RU')}</span></p>` +
    `<img src="${img}" alt="схема загрузки"></body></html>`;
  const blob = new Blob([html], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `loadsmart_${name}.html`;
  a.click();
  URL.revokeObjectURL(a.href);
}

async function calculateLoad() {
  const sel = document.getElementById('vehicleSelect');
  // если список пустой (сервер не отвечал при старте) — пробуем перезагрузить
  if (sel.options.length <= 1) {
    const ok = await refreshVehicleList();
    if (!ok) return;
  }
  if (sel.value) loadAndRender(Number(sel.value));
}

Object.assign(window, { initPlanner, calculateLoad, exportScene, setView, toggleHeatmap, refreshVehicleList, loadAndRender });
