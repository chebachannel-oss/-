// Дашборд: KPI-карточки (/api/stats) и графики Plotly (/api/analytics).

const PLOT_LAYOUT = {
  paper_bgcolor: 'transparent',
  plot_bgcolor: 'transparent',
  font: { color: '#9aa6b5', family: 'IBM Plex Mono, monospace', size: 11 },
  margin: { t: 12, r: 16, b: 40, l: 48 },
  xaxis: { gridcolor: '#222b36', zerolinecolor: '#222b36' },
  yaxis: { gridcolor: '#222b36', zerolinecolor: '#222b36' },
  legend: { font: { color: '#9aa6b5' }, orientation: 'h', y: -0.2 },
};
const PLOT_CONFIG = { displayModeBar: false, responsive: true };

const STATUS_RU2 = {
  new: 'Новый', assigned: 'Назначен', loaded: 'Загружен',
  delivered: 'Доставлен', cancelled: 'Отменён',
};

function loadColor(pct) {
  if (pct > 85) return '#ef4444';
  if (pct >= 55) return '#f59e0b';
  return '#22c55e';
}

function animateNumber(el, target, suffix = '') {
  if (!el) return;
  const start = 0, dur = 600, t0 = performance.now();
  const isFloat = !Number.isInteger(target);
  function tick(t) {
    const k = Math.min((t - t0) / dur, 1);
    const ease = 1 - Math.pow(1 - k, 3);
    const val = start + (target - start) * ease;
    el.textContent = (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
    if (k < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

async function loadStats() {
  try {
    const s = await getStats();
    animateNumber(document.getElementById('cardOrders'), s.orders_today);
    document.getElementById('cardVehicles').textContent = `${s.vehicles_busy} / ${s.vehicles_total}`;
    animateNumber(document.getElementById('cardLoad'), s.avg_load_pct, '%');
    animateNumber(document.getElementById('cardWeight'), s.avg_weight_pct, '%');
    animateNumber(document.getElementById('cardPallets'), s.pallets_total);
    animateNumber(document.getElementById('cardUnassigned'), s.unassigned_orders);
    const sub = document.getElementById('cardOrdersSub');
    if (sub) sub.textContent = `всего ${s.orders_total}`;
    const wsub = document.getElementById('cardWeightSub');
    if (wsub) wsub.textContent = `${Math.round(s.weight_total_kg)} кг в работе`;
  } catch (e) {
    ['cardOrders', 'cardVehicles', 'cardLoad', 'cardWeight', 'cardPallets', 'cardUnassigned']
      .forEach(id => { const el = document.getElementById(id); if (el) el.textContent = '—'; });
  }
}

async function loadAnalytics() {
  let a;
  try {
    a = await getAnalytics();
  } catch (e) {
    document.getElementById('chartLoad').innerHTML =
      `<div class="state error">Не удалось загрузить данные. Проверьте подключение к серверу.</div>`;
    return;
  }

  // 1 — загрузка машин: объём + масса (grouped bar)
  Plotly.newPlot('chartLoad', [
    {
      type: 'bar', name: 'Объём',
      x: a.vehicles_load.map(v => v.name),
      y: a.vehicles_load.map(v => v.load_pct),
      marker: { color: a.vehicles_load.map(v => loadColor(v.load_pct)) },
      hovertemplate: '%{x}<br>Объём: %{y}%<extra></extra>',
    },
    {
      type: 'bar', name: 'Масса',
      x: a.vehicles_load.map(v => v.name),
      y: a.vehicles_load.map(v => v.weight_pct),
      marker: { color: 'rgba(255,255,255,.18)', line: { color: '#5b6673', width: 1 } },
      hovertemplate: '%{x}<br>Масса: %{y}%<extra></extra>',
    },
  ], {
    ...PLOT_LAYOUT, barmode: 'group',
    yaxis: {
      ...PLOT_LAYOUT.yaxis, range: [0, 110], ticksuffix: '%',
      tickmode: 'linear', tick0: 0, dtick: 20, autorange: false,
    },
    xaxis: { ...PLOT_LAYOUT.xaxis, type: 'category' },
  }, PLOT_CONFIG);

  // 2 — типы груза (donut)
  const cargoRu = { standard: 'Стандартный', fragile: 'Хрупкий', oversize: 'Негабаритный' };
  Plotly.newPlot('chartCargo', [{
    type: 'pie', hole: 0.55,
    labels: a.cargo_types.map(c => cargoRu[c.type] || c.type),
    values: a.cargo_types.map(c => c.count),
    marker: { colors: ['#3b82f6', '#ef4444', '#f59e0b'], line: { color: '#14171c', width: 2 } },
    textfont: { color: '#fff' },
  }], { ...PLOT_LAYOUT, showlegend: true }, PLOT_CONFIG);

  // 3 — статусы заказов (horizontal bar)
  Plotly.newPlot('chartStatus', [{
    type: 'bar', orientation: 'h',
    y: a.statuses.map(s => STATUS_RU2[s.status] || s.status),
    x: a.statuses.map(s => s.count),
    marker: { color: ['#5b6673', '#3b82f6', '#f1c40f', '#22c55e', '#ef4444'] },
    hovertemplate: '%{y}: %{x}<extra></extra>',
  }], { ...PLOT_LAYOUT, margin: { t: 12, r: 16, b: 30, l: 90 } }, PLOT_CONFIG);

  // 4 — заказы и палеты по дням (line + bar)
  Plotly.newPlot('chartDays', [
    {
      type: 'bar', name: 'Палеты',
      x: a.orders_by_day.map(d => d.date.slice(5)),
      y: a.orders_by_day.map(d => d.pallets),
      marker: { color: 'rgba(255,122,24,.25)' },
      yaxis: 'y2', hovertemplate: '%{x}<br>%{y} палет<extra></extra>',
    },
    {
      type: 'scatter', mode: 'lines+markers', name: 'Заказы',
      x: a.orders_by_day.map(d => d.date.slice(5)),
      y: a.orders_by_day.map(d => d.count),
      line: { color: '#ff7a18', width: 3, shape: 'spline' },
      marker: { color: '#ffb454', size: 8 },
      hovertemplate: '%{x}<br>%{y} заказ.<extra></extra>',
    },
  ], {
    ...PLOT_LAYOUT,
    yaxis: { ...PLOT_LAYOUT.yaxis, title: '' },
    yaxis2: { overlaying: 'y', side: 'right', gridcolor: 'transparent', showticklabels: false },
  }, PLOT_CONFIG);

  // экологическая плашка
  const eco = document.getElementById('ecoLine');
  if (eco) eco.textContent =
    `≈ ${a.co2_kg} кг CO₂ · в среднем ${a.avg_pallets_per_order} палет/заказ`;

  resizeCharts();
}

// Plotly не пересчитывает размер, если график рисовался в скрытой вкладке —
// форсируем пересчёт после того, как вёрстка устаканилась.
function resizeCharts() {
  const ids = ['chartLoad', 'chartCargo', 'chartStatus', 'chartDays'];
  requestAnimationFrame(() => {
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el && el.querySelector('.plot-container') && window.Plotly) {
        try { Plotly.Plots.resize(el); } catch (e) {}
      }
    });
  });
}

function refreshAnalytics() { loadStats(); loadAnalytics(); }

Object.assign(window, { loadStats, loadAnalytics, refreshAnalytics, resizeCharts });
