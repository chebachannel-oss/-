// Таблица заказов: рендер, фильтры, смена статуса, создание заказа, авто-назначение.

const CARGO_RU = { standard: 'Стандартный', fragile: 'Хрупкий', oversize: 'Негабаритный' };
const STATUS_RU = {
  new: 'Новый', assigned: 'Назначен', loaded: 'Загружен',
  delivered: 'Доставлен', cancelled: 'Отменён',
};
const PRIO_RU = { urgent: 'Срочный', normal: 'Обычный' };

function fmtDate(iso) {
  const p = (iso || '').split('-');
  return p.length === 3 ? `${p[2]}.${p[1]}` : iso || '—';
}

function statusSelect(order) {
  const opts = Object.entries(STATUS_RU)
    .map(([k, v]) => `<option value="${k}" ${k === order.status ? 'selected' : ''}>${v}</option>`)
    .join('');
  return `<select onchange="changeStatus(${order.id}, this.value)">${opts}</select>`;
}

async function renderOrders() {
  const host = document.getElementById('ordersHost');
  host.innerHTML = `<div class="state"><div class="spinner"></div>Загрузка...</div>`;

  const filters = {
    status: document.getElementById('fStatus').value,
    cargo_type: document.getElementById('fCargo').value,
    date: document.getElementById('fDate').value,
    q: document.getElementById('fQuery').value.trim(),
  };

  let orders;
  try {
    orders = await getOrders({ status: filters.status, date: filters.date, q: filters.q });
  } catch (e) {
    host.innerHTML = `<div class="state error">Не удалось загрузить данные. Проверьте подключение к серверу.</div>`;
    return;
  }

  if (filters.cargo_type) orders = orders.filter(o => o.cargo_type === filters.cargo_type);

  // мини-счётчик
  const counter = document.getElementById('ordersCount');
  if (counter) counter.textContent = `${orders.length} зак.`;

  if (!orders.length) {
    host.innerHTML = `<div class="state">Заказов не найдено</div>`;
    return;
  }

  const rows = orders.map(o => {
    const prioDot = o.priority === 'urgent'
      ? '<span class="dot urgent" title="Срочный"></span>'
      : '<span class="dot normal" title="Обычный"></span>';
    const assignBtn = (!o.vehicle_name && o.status !== 'cancelled' && o.status !== 'delivered')
      ? `<button class="mini-btn" onclick="autoAssign(${o.id})">Подобрать</button>` : '';
    const dims = `${o.pallet_length_m}×${o.pallet_width_m}×${o.pallet_height_m}`;
    return `
    <tr>
      <td class="mono">#${o.id}</td>
      <td>${prioDot}${o.recipient}<br><span class="sub mono">${o.client_order_id}</span></td>
      <td class="mono">${o.pallet_count}<br><span class="sub">${dims} м</span></td>
      <td>${CARGO_RU[o.cargo_type] || o.cargo_type}</td>
      <td class="mono">${Math.round(o.total_weight_kg)} кг<br><span class="sub">${o.total_volume_m3} м³</span></td>
      <td>${o.vehicle_name || '—'} ${assignBtn}</td>
      <td class="mono">${fmtDate(o.shipment_date)}</td>
      <td><span class="badge st-${o.status}">${STATUS_RU[o.status] || o.status}</span></td>
      <td>${statusSelect(o)}</td>
    </tr>`;
  }).join('');

  host.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>№</th><th>Получатель</th><th>Палет</th><th>Тип груза</th><th>Масса</th>
          <th>Машина</th><th>Дата</th><th>Статус</th><th>Изменить</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function applyFilters() { renderOrders(); }

function resetFilters() {
  document.getElementById('fStatus').value = '';
  document.getElementById('fCargo').value = '';
  document.getElementById('fDate').value = '';
  document.getElementById('fQuery').value = '';
  renderOrders();
}

async function changeStatus(orderId, status) {
  try {
    await updateOrderStatus(orderId, status);
    renderOrders();
  } catch (e) {
    toast('Не удалось обновить статус', true);
  }
}

async function autoAssign(orderId) {
  try {
    const res = await assignOrder(orderId);
    if (res.vehicle_name) {
      toast(`Назначена: ${res.vehicle_name} (${res.vehicle_load_after_pct}%)`);
    } else {
      toast(res.warning || 'Нет подходящей машины', true);
    }
    renderOrders();
  } catch (e) {
    toast('Ошибка назначения', true);
  }
}

// ---------- создание заказа ----------
// Пресеты палет: [Д, Ш, В] в метрах
const PALLET_PRESETS = {
  eur: [1.2, 0.8, 1.0, 'EUR 1.2×0.8'],
  fin: [1.2, 1.0, 1.2, 'FIN 1.2×1.0'],
  ind: [1.2, 1.2, 1.5, 'Промышленная 1.2×1.2'],
  half: [0.8, 0.6, 0.8, 'Полупалета 0.8×0.6'],
};

function openCreate() {
  document.getElementById('createModal').classList.add('open');
  applyPalletPreset('eur');
  const d = document.getElementById('createModal').querySelector('[name=shipment_date]');
  if (d && !d.value) d.value = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
}
function closeCreate() { document.getElementById('createModal').classList.remove('open'); }

function applyPalletPreset(key) {
  const f = document.getElementById('orderForm');
  if (!f) return;
  if (key !== 'custom' && PALLET_PRESETS[key]) {
    const [l, w, h] = PALLET_PRESETS[key];
    f.pallet_length_m.value = l;
    f.pallet_width_m.value = w;
    f.pallet_height_m.value = h;
  }
  document.querySelectorAll('.preset-chip').forEach(c => c.classList.toggle('active', c.dataset.preset === key));
  updateOrderPreview();
}

function updateOrderPreview() {
  const f = document.getElementById('orderForm');
  if (!f) return;
  const l = Number(f.pallet_length_m.value) || 0;
  const w = Number(f.pallet_width_m.value) || 0;
  const h = Number(f.pallet_height_m.value) || 0;
  const n = Number(f.pallet_count.value) || 0;
  const wt = Number(f.pallet_weight_kg.value) || 0;
  const vol = l * w * h;
  const el = document.getElementById('orderPreview');
  if (el) el.innerHTML =
    `1 палета: <b>${vol.toFixed(2)} м³</b> · Итого: <b>${(vol * n).toFixed(2)} м³</b> / <b>${Math.round(wt * n)} кг</b>`;
}

async function submitCreate(ev) {
  ev.preventDefault();
  const f = ev.target;
  const conds = [];
  if (f.no_tilt.checked) conds.push('no_tilt');
  if (f.temperature.checked) conds.push('temperature');
  const payload = {
    client_order_id: f.client_order_id.value.trim() || `WEB-${Date.now() % 100000}`,
    recipient: f.recipient.value.trim(),
    delivery_address: f.delivery_address.value.trim(),
    shipment_date: f.shipment_date.value || new Date().toISOString().slice(0, 10),
    priority: f.priority.value,
    pallet_count: Number(f.pallet_count.value),
    cargo_type: f.cargo_type.value,
    pallet_length_m: Number(f.pallet_length_m.value),
    pallet_width_m: Number(f.pallet_width_m.value),
    pallet_height_m: Number(f.pallet_height_m.value),
    pallet_weight_kg: Number(f.pallet_weight_kg.value),
    special_conditions: conds,
  };
  try {
    const res = await createOrder(payload);
    closeCreate();
    f.reset();
    if (res.vehicle_name) {
      toast(`Заказ #${res.order_id} → ${res.vehicle_name} (${res.vehicle_load_after_pct}%)`);
    } else {
      toast(`Заказ #${res.order_id} создан. ${res.warning || 'машина не подобрана'}`, true);
    }
    renderOrders();
  } catch (e) {
    toast('Не удалось создать заказ: ' + e.message, true);
  }
}

// ---------- toast ----------
let _toastTimer;
function toast(msg, isError = false) {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => (el.className = 'toast'), 3200);
}

Object.assign(window, {
  renderOrders, applyFilters, resetFilters, changeStatus, autoAssign,
  openCreate, closeCreate, submitCreate, toast,
  applyPalletPreset, updateOrderPreview,
});
