"""Pydantic-схемы запросов и ответов. Имена полей строго по ТЗ — их ждёт бот и фронт."""
from __future__ import annotations

from pydantic import BaseModel, Field


# ---------- POST /api/orders ----------
class OrderCreate(BaseModel):
    client_order_id: str = Field(min_length=1, max_length=50)
    recipient: str = Field(min_length=1)
    delivery_address: str = Field(min_length=1)
    shipment_date: str                       # 'YYYY-MM-DD'
    priority: str                            # urgent / normal
    pallet_count: int = Field(ge=1, le=66)
    cargo_type: str                          # standard / fragile / oversize
    # габариты одной палеты в метрах — пользователь задаёт сам
    pallet_length_m: float = Field(default=1.2, gt=0, le=6.0)
    pallet_width_m: float = Field(default=0.8, gt=0, le=3.0)
    pallet_height_m: float = Field(default=1.2, gt=0, le=3.0)
    pallet_weight_kg: float = Field(gt=0, le=1500)
    # объём считается из габаритов; поле оставлено для обратной совместимости с ботом
    pallet_volume_m3: float | None = Field(default=None, gt=0, le=20.0)
    special_conditions: list[str] = Field(default_factory=list)


class OrderCreateResponse(BaseModel):
    order_id: int
    vehicle_name: str | None = None
    vehicle_load_before_pct: int | None = None
    vehicle_load_after_pct: int | None = None
    status: str
    warning: str | None = None


# ---------- GET /api/orders, PATCH .../status ----------
class OrderOut(BaseModel):
    id: int
    client_order_id: str
    recipient: str
    delivery_address: str
    shipment_date: str
    priority: str
    pallet_count: int
    cargo_type: str
    pallet_length_m: float
    pallet_width_m: float
    pallet_height_m: float
    pallet_weight_kg: float
    pallet_volume_m3: float
    total_volume_m3: float
    total_weight_kg: float
    special_conditions: str
    vehicle_id: int | None
    vehicle_name: str | None
    status: str
    created_at: str


class StatusUpdate(BaseModel):
    status: str


# ---------- POST /api/vehicles ----------
class VehicleCreate(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    type: str = "truck"   # gazelle / gazelle_next / refrigerator / truck
    length_m: float = Field(gt=0, le=20)
    width_m: float = Field(gt=0, le=4)
    height_m: float = Field(gt=0, le=4)
    max_weight_kg: float = Field(gt=0, le=50000)
    axles: int = Field(default=2, ge=2, le=5)
    description: str = ""


# ---------- GET /api/vehicles ----------
class VehicleOut(BaseModel):
    id: int
    name: str
    type: str
    length_m: float
    width_m: float
    height_m: float
    volume_m3: float
    max_weight_kg: float
    axles: int
    description: str
    used_volume_m3: float
    used_weight_kg: float
    load_pct: int
    weight_pct: int
    orders_count: int
    is_available: bool


# ---------- GET /api/stats ----------
class StatsOut(BaseModel):
    orders_today: int
    orders_total: int
    vehicles_busy: int
    vehicles_total: int
    avg_load_pct: float
    avg_weight_pct: float
    fragile_orders: int
    urgent_orders: int
    pallets_total: int
    weight_total_kg: float
    unassigned_orders: int


# ---------- GET /api/analytics ----------
class VehicleLoad(BaseModel):
    name: str
    load_pct: int
    weight_pct: int


class CargoTypeCount(BaseModel):
    type: str
    count: int


class OrdersByDay(BaseModel):
    date: str
    count: int
    pallets: int


class StatusCount(BaseModel):
    status: str
    count: int


class PriorityCount(BaseModel):
    priority: str
    count: int


class AnalyticsOut(BaseModel):
    vehicles_load: list[VehicleLoad]
    cargo_types: list[CargoTypeCount]
    orders_by_day: list[OrdersByDay]
    statuses: list[StatusCount]
    priorities: list[PriorityCount]
    co2_kg: float
    avg_pallets_per_order: float
