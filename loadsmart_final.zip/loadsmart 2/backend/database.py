"""Создание БД, сессия и наполнение тестовыми данными (seed_data)."""
from __future__ import annotations

import random
from datetime import date, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from algorithm import build_load_plan
from models import Base, Order, Vehicle

DB_URL = "sqlite:///loadsmart.db"
engine = create_engine(DB_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False)


def get_db():
    """Зависимость FastAPI: одна сессия на запрос."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Парк фулфилмент-центра «Маяк»: (name, type, L, W, H, volume, max_kg, axles, descr)
VEHICLES = [
    ("Газель №1", "gazelle", 4.2, 2.0, 2.1, 17.6, 1500, 2, "Городская развозка, тент"),
    ("Газель №2", "gazelle", 4.2, 2.0, 2.1, 17.6, 1500, 2, "Городская развозка, тент"),
    ("Газель Next №1", "gazelle_next", 5.1, 2.2, 2.2, 24.6, 2200, 2, "Удлинённый цельнометаллический фургон"),
    ("Рефрижератор Hyundai", "refrigerator", 6.2, 2.4, 2.4, 35.7, 5000, 2, "Изотермический кузов −20…+12 °C"),
    ("Фура МАЗ-1", "truck", 13.6, 2.45, 2.7, 90.0, 20000, 3, "Стандартный еврофургон 82 м³"),
    ("Фура МАЗ-2", "truck", 13.6, 2.45, 2.7, 90.0, 20000, 3, "Стандартный еврофургон 82 м³"),
    ("Фура Scania", "truck", 13.6, 2.45, 3.0, 100.0, 22000, 3, "Высокий тент Mega, 100 м³"),
]

# пресеты палет для сидера: (length, width, height)
PALLET_PRESETS = [
    (1.2, 0.8, 1.0),    # EUR
    (1.2, 0.8, 1.4),
    (1.2, 1.0, 1.2),    # FIN
    (1.2, 1.2, 1.5),    # промышленная
    (0.8, 0.6, 0.8),    # полупалета
]

RECIPIENTS = [
    "ООО Логистик Плюс", "ИП Сидоров А.В.", "АО ТД Восток",
    "ООО Маяк-Снаб", "Wildberries РЦ Электросталь", "Ozon Фулфилмент",
    "ООО СеверТранс", "ПАО РЖД-Логистика",
]
ADDRESSES = [
    "Москва, ул. Складская, д. 5", "Электросталь, ш. Энтузиастов, 12",
    "Подольск, ул. Заводская, 7", "Мытищи, Олимпийский пр-т, 29",
    "Люберцы, ул. Транспортная, 3",
]
CARGO = ["standard", "fragile", "oversize"]
STATUSES = ["new", "assigned", "loaded", "delivered", "cancelled"]


def init_db() -> None:
    Base.metadata.create_all(engine)


def seed_data() -> None:
    """Заполнить БД при первом запуске: 5 машин и 20 заказов за 7 дней."""
    init_db()
    db: Session = SessionLocal()
    try:
        if db.query(Vehicle).count() > 0:
            return  # уже заполнено

        vehicles = [
            Vehicle(
                name=n, type=t, length_m=l, width_m=w, height_m=h,
                volume_m3=v, max_weight_kg=mw, axles=ax, description=descr,
                is_available=1,
            )
            for (n, t, l, w, h, v, mw, ax, descr) in VEHICLES
        ]
        db.add_all(vehicles)
        db.flush()

        rng = random.Random(42)
        today = date.today()

        for i in range(38):
            day_offset = rng.randint(0, 6)
            created = datetime.now() - timedelta(days=day_offset)
            ship = today + timedelta(days=rng.randint(0, 5))
            cargo = rng.choices(CARGO, weights=[6, 3, 2])[0]
            pallets = rng.randint(2, 9)
            p_weight = rng.choice([120, 180, 240, 320, 450])
            pl, pw, ph = rng.choice(PALLET_PRESETS)
            if cargo == "oversize":      # негабарит — крупнее, но компактнее по footprint
                pl, pw, ph = 1.2, 1.0, rng.choice([1.4, 1.6, 1.8])
            p_volume = round(pl * pw * ph, 3)
            priority = rng.choice(["urgent", "normal"])
            status = rng.choices(
                STATUSES, weights=[1, 4, 3, 3, 1]
            )[0]

            order = Order(
                client_order_id=f"ЗАК-2025-{400 + i}",
                recipient=rng.choice(RECIPIENTS),
                delivery_address=rng.choice(ADDRESSES),
                shipment_date=ship.isoformat(),
                priority=priority,
                pallet_count=pallets,
                cargo_type=cargo,
                pallet_length_m=pl,
                pallet_width_m=pw,
                pallet_height_m=ph,
                pallet_weight_kg=p_weight,
                pallet_volume_m3=p_volume,
                total_volume_m3=round(pallets * p_volume, 2),
                total_weight_kg=round(pallets * p_weight, 2),
                special_conditions=rng.choice(["", "no_tilt", "temperature", "no_tilt,temperature"]),
                status=status,
                created_at=created.strftime("%Y-%m-%d %H:%M:%S"),
            )
            # Назначаем машину только если РЕАЛЬНЫЙ упаковщик уложит всё без потерь
            # и не превышен лимит массы. Так в демо-данных ничего не «висит» зря.
            if status in ("assigned", "loaded", "delivered"):
                def used_w(v):
                    return sum(o.total_weight_kg for o in v.orders if o.status != "cancelled")

                fit = []
                for v in vehicles:
                    if used_w(v) + order.total_weight_kg > v.max_weight_kg:
                        continue
                    trial = [o for o in v.orders if o.status != "cancelled"] + [order]
                    plan = build_load_plan(v, trial)
                    if plan["unplaced_count"] == 0:
                        fit.append((v, plan["fill_pct"]))
                if fit:
                    fit.sort(key=lambda c: -c[1])   # самая заполненная — консолидация
                    order.vehicle = fit[0][0]
            db.add(order)

        db.flush()
        # машины, заполненные >90%, помечаем занятыми
        for v in vehicles:
            used = sum(o.total_volume_m3 for o in v.orders if o.status != "cancelled")
            if v.volume_m3 and used / v.volume_m3 > 0.9:
                v.is_available = 0
        db.commit()
    finally:
        db.close()
