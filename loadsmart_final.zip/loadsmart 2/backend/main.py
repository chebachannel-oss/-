"""Точка входа LoadSmart backend.

Запуск:  uvicorn main:app --reload --port 8000
Документация: http://localhost:8000/docs
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import seed_data
from routers import analytics, load_plan, orders, vehicles

app = FastAPI(title="LoadSmart API", version="1.0")

# CORS — без этого браузер фронта не достучится до сервера.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(orders.router)
app.include_router(vehicles.router)
app.include_router(analytics.router)
app.include_router(load_plan.router)


@app.on_event("startup")
def on_startup() -> None:
    seed_data()  # создаёт БД и тестовые данные при первом запуске


@app.get("/")
def root():
    return {"service": "LoadSmart API", "docs": "/docs"}
