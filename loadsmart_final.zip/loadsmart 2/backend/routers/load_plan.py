"""Координаты палет для Three.js."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from algorithm import build_load_plan
from database import get_db
from models import Order, Vehicle

router = APIRouter(prefix="/api", tags=["load-plan"])


@router.get("/load-plan")
def load_plan(vehicle_id: int = Query(...), db: Session = Depends(get_db)):
    vehicle = db.get(Vehicle, vehicle_id)
    if vehicle is None:
        raise HTTPException(status_code=404, detail="Машина не найдена")

    orders = (
        db.query(Order)
        .filter(Order.vehicle_id == vehicle_id, Order.status != "cancelled")
        .all()
    )
    return build_load_plan(vehicle, orders)
