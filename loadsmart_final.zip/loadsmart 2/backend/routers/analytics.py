"""Агрегаты для графиков на дашборде."""
from __future__ import annotations

from collections import Counter
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from algorithm import vehicle_load_pct, vehicle_weight_pct
from database import get_db
from models import Order, Vehicle
from schemas import (
    AnalyticsOut,
    CargoTypeCount,
    OrdersByDay,
    PriorityCount,
    StatusCount,
    VehicleLoad,
)

router = APIRouter(prefix="/api", tags=["analytics"])

# усреднённый выброс CO2: ~0.9 кг на тонну·100км, считаем условные 50 км маршрута
CO2_PER_KG = 0.9 / 1000 * 0.5


@router.get("/analytics", response_model=AnalyticsOut)
def analytics(db: Session = Depends(get_db)):
    vehicles = db.query(Vehicle).order_by(Vehicle.id).all()
    orders = db.query(Order).filter(Order.status != "cancelled").all()

    vehicles_load = [
        VehicleLoad(name=v.name, load_pct=vehicle_load_pct(v), weight_pct=vehicle_weight_pct(v))
        for v in vehicles
    ]

    cargo_counter = Counter(o.cargo_type for o in orders)
    cargo_types = [
        CargoTypeCount(type=t, count=cargo_counter.get(t, 0))
        for t in ("standard", "fragile", "oversize")
    ]

    all_orders = db.query(Order).all()
    status_counter = Counter(o.status for o in all_orders)
    statuses = [
        StatusCount(status=s, count=status_counter.get(s, 0))
        for s in ("new", "assigned", "loaded", "delivered", "cancelled")
    ]

    prio_counter = Counter(o.priority for o in orders)
    priorities = [
        PriorityCount(priority=p, count=prio_counter.get(p, 0))
        for p in ("urgent", "normal")
    ]

    today = date.today()
    day_orders: Counter[str] = Counter((o.created_at or "")[:10] for o in orders)
    day_pallets: Counter[str] = Counter()
    for o in orders:
        day_pallets[(o.created_at or "")[:10]] += o.pallet_count
    orders_by_day = []
    for i in range(6, -1, -1):
        d = (today - timedelta(days=i)).isoformat()
        orders_by_day.append(
            OrdersByDay(date=d, count=day_orders.get(d, 0), pallets=day_pallets.get(d, 0))
        )

    total_weight = sum(o.total_weight_kg for o in orders)
    pallets_total = sum(o.pallet_count for o in orders)
    co2 = round(total_weight * CO2_PER_KG, 1)
    avg_pallets = round(pallets_total / len(orders), 1) if orders else 0.0

    return AnalyticsOut(
        vehicles_load=vehicles_load,
        cargo_types=cargo_types,
        orders_by_day=orders_by_day,
        statuses=statuses,
        priorities=priorities,
        co2_kg=co2,
        avg_pallets_per_order=avg_pallets,
    )
