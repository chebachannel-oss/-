"""Автопарк: список, добавление и удаление машин."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from algorithm import (
    vehicle_load_pct,
    vehicle_used_volume,
    vehicle_used_weight,
    vehicle_weight_pct,
)
from database import get_db
from models import Vehicle
from schemas import VehicleCreate, VehicleOut

router = APIRouter(prefix="/api", tags=["vehicles"])


def _to_out(v: Vehicle) -> VehicleOut:
    return VehicleOut(
        id=v.id, name=v.name, type=v.type,
        length_m=v.length_m, width_m=v.width_m, height_m=v.height_m,
        volume_m3=v.volume_m3, max_weight_kg=v.max_weight_kg,
        axles=v.axles or 2, description=v.description or "",
        used_volume_m3=round(vehicle_used_volume(v), 2),
        used_weight_kg=round(vehicle_used_weight(v), 1),
        load_pct=vehicle_load_pct(v), weight_pct=vehicle_weight_pct(v),
        orders_count=sum(1 for o in v.orders if o.status != "cancelled"),
        is_available=bool(v.is_available),
    )


@router.get("/vehicles", response_model=list[VehicleOut])
def list_vehicles(db: Session = Depends(get_db)):
    vehicles = db.query(Vehicle).order_by(Vehicle.id).all()
    return [_to_out(v) for v in vehicles]


@router.post("/vehicles", response_model=VehicleOut, status_code=201)
def create_vehicle(payload: VehicleCreate, db: Session = Depends(get_db)):
    volume = round(payload.length_m * payload.width_m * payload.height_m, 2)
    v = Vehicle(
        name=payload.name, type=payload.type,
        length_m=payload.length_m, width_m=payload.width_m, height_m=payload.height_m,
        volume_m3=volume, max_weight_kg=payload.max_weight_kg,
        axles=payload.axles, description=payload.description, is_available=1,
    )
    db.add(v)
    db.commit()
    db.refresh(v)
    return _to_out(v)


@router.delete("/vehicles/{vehicle_id}")
def delete_vehicle(vehicle_id: int, db: Session = Depends(get_db)):
    v = db.get(Vehicle, vehicle_id)
    if v is None:
        raise HTTPException(status_code=404, detail="Машина не найдена")
    active = [o for o in v.orders if o.status != "cancelled"]
    if active:
        # ничего не теряем: открепляем заказы и возвращаем их в статус «новый»
        for o in active:
            o.vehicle_id = None
            o.status = "new"
    db.delete(v)
    db.commit()
    return {"deleted": vehicle_id, "released_orders": len(active)}
