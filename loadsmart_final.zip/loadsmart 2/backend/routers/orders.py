"""CRUD заказов + сводка /api/stats."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from algorithm import (
    vehicle_load_pct,
    vehicle_used_volume,
    vehicle_used_weight,
    vehicle_weight_pct,
)
from database import get_db
from models import Order, Vehicle
from schemas import (
    OrderCreate,
    OrderCreateResponse,
    OrderOut,
    StatsOut,
    StatusUpdate,
)

router = APIRouter(prefix="/api", tags=["orders"])


def order_to_out(o: Order) -> dict:
    """Заказ -> словарь для OrderOut (с именем машины из JOIN)."""
    return {
        "id": o.id,
        "client_order_id": o.client_order_id,
        "recipient": o.recipient,
        "delivery_address": o.delivery_address,
        "shipment_date": o.shipment_date,
        "priority": o.priority,
        "pallet_count": o.pallet_count,
        "cargo_type": o.cargo_type,
        "pallet_length_m": o.pallet_length_m or 1.2,
        "pallet_width_m": o.pallet_width_m or 0.8,
        "pallet_height_m": o.pallet_height_m or 1.2,
        "pallet_weight_kg": o.pallet_weight_kg,
        "pallet_volume_m3": o.pallet_volume_m3,
        "total_volume_m3": o.total_volume_m3,
        "total_weight_kg": o.total_weight_kg,
        "special_conditions": o.special_conditions or "",
        "vehicle_id": o.vehicle_id,
        "vehicle_name": o.vehicle.name if o.vehicle else None,
        "status": o.status,
        "created_at": o.created_at,
    }


@router.post("/orders", response_model=OrderCreateResponse)
def create_order(payload: OrderCreate, db: Session = Depends(get_db)):
    # объём палеты: из габаритов, либо из переданного значения (бот), либо по умолчанию
    pallet_volume = round(payload.pallet_length_m * payload.pallet_width_m * payload.pallet_height_m, 3)
    if payload.pallet_volume_m3:
        pallet_volume = payload.pallet_volume_m3
    total_volume = round(payload.pallet_count * pallet_volume, 2)
    total_weight = round(payload.pallet_count * payload.pallet_weight_kg, 2)

    order = Order(
        client_order_id=payload.client_order_id,
        recipient=payload.recipient,
        delivery_address=payload.delivery_address,
        shipment_date=payload.shipment_date,
        priority=payload.priority,
        pallet_count=payload.pallet_count,
        cargo_type=payload.cargo_type,
        pallet_length_m=payload.pallet_length_m,
        pallet_width_m=payload.pallet_width_m,
        pallet_height_m=payload.pallet_height_m,
        pallet_weight_kg=payload.pallet_weight_kg,
        pallet_volume_m3=pallet_volume,
        total_volume_m3=total_volume,
        total_weight_kg=total_weight,
        special_conditions=",".join(payload.special_conditions),
        status="new",
    )

    # best-fit: свободная машина с минимальным остатком объёма, проходящая по массе
    candidates: list[tuple[Vehicle, float]] = []
    for v in db.query(Vehicle).all():
        free = v.volume_m3 - vehicle_used_volume(v)
        free_w = v.max_weight_kg - vehicle_used_weight(v)
        if v.is_available == 1 and free >= total_volume and free_w >= total_weight:
            candidates.append((v, free))

    if not candidates:
        db.add(order)
        db.commit()
        db.refresh(order)
        return OrderCreateResponse(
            order_id=order.id,
            vehicle_name=None,
            status="new",
            warning="Нет доступных машин подходящего объёма",
        )

    vehicle, free = min(candidates, key=lambda c: c[1])
    load_before = vehicle_load_pct(vehicle)

    order.vehicle = vehicle
    order.status = "assigned"
    db.add(order)
    db.flush()

    load_after = vehicle_load_pct(vehicle)
    if load_after > 90:
        vehicle.is_available = 0

    db.commit()
    db.refresh(order)
    return OrderCreateResponse(
        order_id=order.id,
        vehicle_name=vehicle.name,
        vehicle_load_before_pct=load_before,
        vehicle_load_after_pct=load_after,
        status="assigned",
    )


@router.get("/orders", response_model=list[OrderOut])
def list_orders(
    status: str | None = Query(default=None),
    date: str | None = Query(default=None),
    priority: str | None = Query(default=None),
    q: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    query = db.query(Order)
    if status:
        query = query.filter(Order.status == status)
    if date:
        query = query.filter(Order.shipment_date == date)
    if priority:
        query = query.filter(Order.priority == priority)
    if q:
        query = query.filter(Order.client_order_id.contains(q))
    orders = query.order_by(Order.id.desc()).all()
    return [order_to_out(o) for o in orders]


@router.patch("/orders/{order_id}/status", response_model=OrderOut)
def update_status(order_id: int, payload: StatusUpdate, db: Session = Depends(get_db)):
    order = db.get(Order, order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    order.status = payload.status
    db.commit()
    db.refresh(order)
    return order_to_out(order)


@router.get("/stats", response_model=StatsOut)
def stats(db: Session = Depends(get_db)):
    orders = db.query(Order).all()
    vehicles = db.query(Vehicle).all()
    today = date.today().isoformat()

    orders_today = sum(1 for o in orders if (o.created_at or "")[:10] == today)
    active = [o for o in orders if o.status != "cancelled"]
    fragile = sum(1 for o in active if o.cargo_type == "fragile")
    urgent = sum(1 for o in active if o.priority == "urgent")
    unassigned = sum(1 for o in active if o.vehicle_id is None)

    loads = [vehicle_load_pct(v) for v in vehicles]
    weights = [vehicle_weight_pct(v) for v in vehicles]
    avg_load = round(sum(loads) / len(loads), 1) if loads else 0.0
    avg_weight = round(sum(weights) / len(weights), 1) if weights else 0.0
    busy = sum(1 for v in vehicles if v.is_available == 0)

    return StatsOut(
        orders_today=orders_today,
        orders_total=len(orders),
        vehicles_busy=busy,
        vehicles_total=len(vehicles),
        avg_load_pct=avg_load,
        avg_weight_pct=avg_weight,
        fragile_orders=fragile,
        urgent_orders=urgent,
        pallets_total=sum(o.pallet_count for o in active),
        weight_total_kg=round(sum(o.total_weight_kg for o in active), 1),
        unassigned_orders=unassigned,
    )


@router.post("/orders/{order_id}/assign", response_model=OrderCreateResponse)
def assign_order(order_id: int, db: Session = Depends(get_db)):
    """Подобрать и назначить лучшую машину уже существующему заказу (best-fit)."""
    order = db.get(Order, order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Заказ не найден")

    candidates: list[tuple[Vehicle, float]] = []
    for v in db.query(Vehicle).all():
        free = v.volume_m3 - vehicle_used_volume(v)
        free_w = v.max_weight_kg - sum(
            o.total_weight_kg for o in v.orders if o.status != "cancelled"
        )
        if v.is_available == 1 and free >= order.total_volume_m3 and free_w >= order.total_weight_kg:
            candidates.append((v, free))

    if not candidates:
        return OrderCreateResponse(
            order_id=order.id, vehicle_name=None, status=order.status,
            warning="Нет доступных машин подходящего объёма/массы",
        )

    vehicle, _ = min(candidates, key=lambda c: c[1])
    load_before = vehicle_load_pct(vehicle)
    order.vehicle = vehicle
    if order.status == "new":
        order.status = "assigned"
    db.flush()
    load_after = vehicle_load_pct(vehicle)
    if load_after > 90:
        vehicle.is_available = 0
    db.commit()
    db.refresh(order)
    return OrderCreateResponse(
        order_id=order.id, vehicle_name=vehicle.name,
        vehicle_load_before_pct=load_before, vehicle_load_after_pct=load_after,
        status=order.status,
    )
