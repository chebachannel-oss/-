"""LoadSmart Telegram-бот (Катя).

Полноценный бот на aiogram 3.x. Общается с FastAPI-сервером Ивана по HTTP,
поэтому backend (uvicorn main:app) должен быть запущен на API_BASE.

Возможности:
  /start, /help          — приветствие и меню
  /new                   — пошаговое создание заказа (мастер с кнопками)
  /orders                — последние заказы
  /vehicles              — парк машин и их загрузка
  /stats                 — сводка за сегодня
  /load <id>             — план загрузки конкретной машины (текстом)

Запуск:
  export BOT_TOKEN="123456:ABC..."      # токен от @BotFather
  export API_BASE="http://localhost:8000"
  python bot.py
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import date, timedelta

import aiohttp
from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    ReplyKeyboardMarkup,
    KeyboardButton,
)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("loadsmart-bot")

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
API_BASE = os.getenv("API_BASE", "http://localhost:8000")

CARGO_RU = {"standard": "📦 Стандартный", "fragile": "🍷 Хрупкий", "oversize": "📐 Негабаритный"}
PRIO_RU = {"urgent": "🔴 Срочный", "normal": "🟢 Обычный"}
STATUS_RU = {
    "new": "🆕 Новый", "assigned": "🚚 Назначен", "loaded": "📥 Загружен",
    "delivered": "✅ Доставлен", "cancelled": "❌ Отменён",
}

router = Router()


# ---------------- HTTP-клиент к API ----------------
async def api_get(path: str) -> dict | list:
    async with aiohttp.ClientSession() as s:
        async with s.get(f"{API_BASE}{path}", timeout=aiohttp.ClientTimeout(total=10)) as r:
            return await r.json()


async def api_post(path: str, payload: dict) -> dict:
    async with aiohttp.ClientSession() as s:
        async with s.post(
            f"{API_BASE}{path}", json=payload, timeout=aiohttp.ClientTimeout(total=10)
        ) as r:
            return await r.json()


# ---------------- FSM мастера создания заказа ----------------
class NewOrder(StatesGroup):
    recipient = State()
    address = State()
    cargo = State()
    priority = State()
    pallets = State()
    weight = State()
    dims = State()
    confirm = State()


def main_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="➕ Новый заказ"), KeyboardButton(text="📋 Заказы")],
            [KeyboardButton(text="🚚 Машины"), KeyboardButton(text="📊 Сводка")],
        ],
        resize_keyboard=True,
    )


def kb(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=t, callback_data=d) for t, d in row] for row in rows
        ]
    )


# ---------------- базовые команды ----------------
@router.message(CommandStart())
async def cmd_start(m: Message):
    await m.answer(
        "👋 Привет! Я <b>Катя</b> — бот фулфилмент-центра «Маяк».\n\n"
        "Помогаю оформлять заказы и слежу за загрузкой машин.\n"
        "Нажми «➕ Новый заказ» или /help.",
        reply_markup=main_menu(),
    )


@router.message(Command("help"))
async def cmd_help(m: Message):
    await m.answer(
        "<b>Команды:</b>\n"
        "/new — оформить заказ (мастер)\n"
        "/orders — последние заказы\n"
        "/vehicles — парк машин\n"
        "/stats — сводка за сегодня\n"
        "/load <i>id</i> — план загрузки машины",
        reply_markup=main_menu(),
    )


@router.message(Command("stats"))
@router.message(F.text == "📊 Сводка")
async def cmd_stats(m: Message):
    try:
        s = await api_get("/api/stats")
    except Exception:
        return await m.answer("⚠️ Сервер недоступен.")
    await m.answer(
        "📊 <b>Сводка</b>\n"
        f"Заказов сегодня: <b>{s['orders_today']}</b> (всего {s['orders_total']})\n"
        f"Машин в работе: <b>{s['vehicles_busy']}/{s['vehicles_total']}</b>\n"
        f"Средняя загрузка: <b>{s['avg_load_pct']}%</b> по объёму, {s['avg_weight_pct']}% по массе\n"
        f"Палет в работе: <b>{s['pallets_total']}</b> · {s['weight_total_kg']:.0f} кг\n"
        f"🔴 Срочных: {s['urgent_orders']} · 🍷 Хрупких: {s['fragile_orders']}\n"
        f"❗️ Без машины: {s['unassigned_orders']}"
    )


@router.message(Command("vehicles"))
@router.message(F.text == "🚚 Машины")
async def cmd_vehicles(m: Message):
    try:
        vs = await api_get("/api/vehicles")
    except Exception:
        return await m.answer("⚠️ Сервер недоступен.")
    lines = ["🚚 <b>Парк машин</b>\n"]
    for v in vs:
        bar = bar_str(v["load_pct"])
        dot = "🟢" if v["is_available"] else "🔴"
        lines.append(
            f"{dot} <b>{v['name']}</b> · #{v['id']}\n"
            f"   {bar} {v['load_pct']}% об. · {v['weight_pct']}% масса\n"
            f"   {v['used_volume_m3']}/{v['volume_m3']} м³ · заказов: {v['orders_count']}"
        )
    await m.answer("\n".join(lines))


@router.message(Command("orders"))
@router.message(F.text == "📋 Заказы")
async def cmd_orders(m: Message):
    try:
        orders = await api_get("/api/orders")
    except Exception:
        return await m.answer("⚠️ Сервер недоступен.")
    if not orders:
        return await m.answer("Заказов пока нет.")
    lines = ["📋 <b>Последние заказы</b>\n"]
    for o in orders[:10]:
        lines.append(
            f"#{o['id']} · {o['client_order_id']}\n"
            f"   {o['recipient']} · {o['pallet_count']} пал.\n"
            f"   {CARGO_RU.get(o['cargo_type'], o['cargo_type'])} · "
            f"{STATUS_RU.get(o['status'], o['status'])} · "
            f"🚚 {o.get('vehicle_name') or '—'}"
        )
    await m.answer("\n".join(lines))


@router.message(Command("load"))
async def cmd_load(m: Message):
    parts = (m.text or "").split()
    if len(parts) < 2 or not parts[1].isdigit():
        return await m.answer("Использование: /load <id машины>")
    try:
        plan = await api_get(f"/api/load-plan?vehicle_id={parts[1]}")
    except Exception:
        return await m.answer("⚠️ Сервер недоступен.")
    v = plan["vehicle"]
    ax = plan["axle_load"]
    await m.answer(
        f"📐 <b>План загрузки: {v['name']}</b>\n"
        f"Палет уложено: <b>{plan['pallet_count']}</b>"
        + (f" (не влезло: {plan['unplaced_count']})" if plan['unplaced_count'] else "") + "\n"
        f"Объём: {plan['used_volume_m3']}/{v['volume_m3']} м³ ({plan['fill_pct']}%)\n"
        f"Масса: {plan['total_weight_kg']:.0f}/{v['max_weight_kg']:.0f} кг ({plan['weight_pct']}%)\n"
        f"Ярусов: {plan['layers']}\n"
        f"⚖️ Оси: перед {ax['front_kg']} кг ({ax['front_pct']}%) · "
        f"зад {ax['rear_kg']} кг ({ax['rear_pct']}%)\n"
        f"🎯 Устойчивость: {plan['stability_pct']}%"
    )


def bar_str(pct: int, width: int = 10) -> str:
    filled = round(pct / 100 * width)
    filled = max(0, min(width, filled))
    return "▰" * filled + "▱" * (width - filled)


# ---------------- мастер создания заказа ----------------
@router.message(Command("new"))
@router.message(F.text == "➕ Новый заказ")
async def new_start(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(NewOrder.recipient)
    await m.answer("📝 <b>Новый заказ</b>\n\nШаг 1/7. Введите получателя:")


@router.message(NewOrder.recipient)
async def step_recipient(m: Message, state: FSMContext):
    await state.update_data(recipient=m.text.strip())
    await state.set_state(NewOrder.address)
    await m.answer("Шаг 2/7. Адрес доставки:")


@router.message(NewOrder.address)
async def step_address(m: Message, state: FSMContext):
    await state.update_data(delivery_address=m.text.strip())
    await state.set_state(NewOrder.cargo)
    await m.answer(
        "Шаг 3/7. Тип груза:",
        reply_markup=kb([[(CARGO_RU["standard"], "c:standard")],
                         [(CARGO_RU["fragile"], "c:fragile")],
                         [(CARGO_RU["oversize"], "c:oversize")]]),
    )


@router.callback_query(NewOrder.cargo, F.data.startswith("c:"))
async def step_cargo(cq: CallbackQuery, state: FSMContext):
    await state.update_data(cargo_type=cq.data.split(":")[1])
    await state.set_state(NewOrder.priority)
    await cq.message.edit_text(
        "Шаг 4/7. Приоритет:",
        reply_markup=kb([[(PRIO_RU["urgent"], "p:urgent"), (PRIO_RU["normal"], "p:normal")]]),
    )
    await cq.answer()


@router.callback_query(NewOrder.priority, F.data.startswith("p:"))
async def step_priority(cq: CallbackQuery, state: FSMContext):
    await state.update_data(priority=cq.data.split(":")[1])
    await state.set_state(NewOrder.pallets)
    await cq.message.edit_text("Шаг 5/7. Количество палет (1–33):")
    await cq.answer()


@router.message(NewOrder.pallets)
async def step_pallets(m: Message, state: FSMContext):
    if not m.text.isdigit() or not (1 <= int(m.text) <= 33):
        return await m.answer("Введите число от 1 до 33.")
    await state.update_data(pallet_count=int(m.text))
    await state.set_state(NewOrder.weight)
    await m.answer("Шаг 6/7. Вес одной палеты, кг:")


@router.message(NewOrder.weight)
async def step_weight(m: Message, state: FSMContext):
    try:
        w = float(m.text.replace(",", "."))
        assert 0 < w <= 1500
    except Exception:
        return await m.answer("Введите вес от 0 до 1500 кг.")
    await state.update_data(pallet_weight_kg=w)
    await state.set_state(NewOrder.dims)
    await m.answer(
        "Шаг 7/7. Габариты палеты Д×Ш×В в метрах через пробел.\n"
        "Например: <code>1.2 0.8 1.4</code>\n"
        "Или выберите типовую:",
        reply_markup=kb([
            [("EUR 1.2×0.8×1.0", "d:1.2,0.8,1.0"), ("FIN 1.2×1.0×1.2", "d:1.2,1.0,1.2")],
            [("Промыш. 1.2×1.2×1.5", "d:1.2,1.2,1.5"), ("Полу 0.8×0.6×0.8", "d:0.8,0.6,0.8")],
        ]),
    )


async def _finish_dims(state: FSMContext, l: float, w: float, h: float, send):
    await state.update_data(pallet_length_m=l, pallet_width_m=w, pallet_height_m=h)
    d = await state.get_data()
    await state.set_state(NewOrder.confirm)
    vol = round(l * w * h, 3)
    total_v = round(d["pallet_count"] * vol, 2)
    total_w = round(d["pallet_count"] * d["pallet_weight_kg"], 1)
    await send(
        "<b>Проверьте заказ:</b>\n"
        f"Получатель: {d['recipient']}\n"
        f"Адрес: {d['delivery_address']}\n"
        f"Груз: {CARGO_RU[d['cargo_type']]} · {PRIO_RU[d['priority']]}\n"
        f"Палета: {l}×{w}×{h} м ({vol} м³)\n"
        f"Палет: {d['pallet_count']} · {total_v} м³ · {total_w} кг",
        reply_markup=kb([[("✅ Создать", "ok"), ("✖️ Отмена", "cancel")]]),
    )


@router.callback_query(NewOrder.dims, F.data.startswith("d:"))
async def step_dims_preset(cq: CallbackQuery, state: FSMContext):
    l, w, h = (float(x) for x in cq.data[2:].split(","))
    await _finish_dims(state, l, w, h, cq.message.edit_text)
    await cq.answer()


@router.message(NewOrder.dims)
async def step_dims_manual(m: Message, state: FSMContext):
    try:
        l, w, h = (float(x.replace(",", ".")) for x in m.text.split())
        assert all(0 < x <= 6 for x in (l, w, h))
    except Exception:
        return await m.answer("Формат: три числа через пробел, напр. 1.2 0.8 1.4")
    await _finish_dims(state, l, w, h, m.answer)


@router.callback_query(NewOrder.confirm, F.data == "cancel")
async def confirm_cancel(cq: CallbackQuery, state: FSMContext):
    await state.clear()
    await cq.message.edit_text("Отменено.")
    await cq.answer()


@router.callback_query(NewOrder.confirm, F.data == "ok")
async def confirm_ok(cq: CallbackQuery, state: FSMContext):
    d = await state.get_data()
    seq = int(date.today().strftime("%j"))
    payload = {
        "client_order_id": f"TG-{date.today().isoformat()}-{cq.from_user.id % 1000}",
        "recipient": d["recipient"],
        "delivery_address": d["delivery_address"],
        "shipment_date": (date.today() + timedelta(days=1)).isoformat(),
        "priority": d["priority"],
        "pallet_count": d["pallet_count"],
        "cargo_type": d["cargo_type"],
        "pallet_length_m": d["pallet_length_m"],
        "pallet_width_m": d["pallet_width_m"],
        "pallet_height_m": d["pallet_height_m"],
        "pallet_weight_kg": d["pallet_weight_kg"],
        "special_conditions": [],
    }
    try:
        res = await api_post("/api/orders", payload)
    except Exception:
        await state.clear()
        return await cq.message.edit_text("⚠️ Сервер недоступен, заказ не создан.")
    await state.clear()
    if res.get("vehicle_name"):
        txt = (
            f"✅ Заказ <b>#{res['order_id']}</b> создан!\n"
            f"🚚 Назначена машина: <b>{res['vehicle_name']}</b>\n"
            f"Загрузка: {res.get('vehicle_load_before_pct', '?')}% → "
            f"<b>{res.get('vehicle_load_after_pct', '?')}%</b>"
        )
    else:
        txt = (
            f"✅ Заказ <b>#{res['order_id']}</b> создан, но машина не назначена.\n"
            f"⚠️ {res.get('warning', 'нет подходящей машины')}"
        )
    await cq.message.edit_text(txt)
    await cq.answer("Готово!")


async def main():
    if not BOT_TOKEN:
        raise SystemExit("Задайте переменную окружения BOT_TOKEN (токен от @BotFather).")
    bot = Bot(token=BOT_TOKEN, default=None)
    # parse_mode HTML по умолчанию
    from aiogram.client.default import DefaultBotProperties
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)
    log.info("LoadSmart bot started. API_BASE=%s", API_BASE)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
