"""SQLAlchemy-модели таблиц."""
from __future__ import annotations

from sqlalchemy import ForeignKey, Integer, Float, String, Text, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Vehicle(Base):
    __tablename__ = "vehicles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)   # gazelle/gazelle_next/refrigerator/truck
    length_m: Mapped[float] = mapped_column(Float, nullable=False)
    width_m: Mapped[float] = mapped_column(Float, nullable=False)
    height_m: Mapped[float] = mapped_column(Float, nullable=False)
    volume_m3: Mapped[float] = mapped_column(Float, nullable=False)
    max_weight_kg: Mapped[float] = mapped_column(Float, nullable=False)
    axles: Mapped[int] = mapped_column(Integer, default=2)            # число осей (для модели)
    description: Mapped[str] = mapped_column(Text, default="")        # заметка/характеристики
    is_available: Mapped[int] = mapped_column(Integer, default=1)     # 1=свободна, 0=занята

    orders: Mapped[list["Order"]] = relationship(back_populates="vehicle")


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    client_order_id: Mapped[str] = mapped_column(String, nullable=False)
    recipient: Mapped[str] = mapped_column(String, nullable=False)
    delivery_address: Mapped[str] = mapped_column(String, nullable=False)
    shipment_date: Mapped[str] = mapped_column(String, nullable=False)
    priority: Mapped[str] = mapped_column(String, nullable=False)
    pallet_count: Mapped[int] = mapped_column(Integer, nullable=False)
    cargo_type: Mapped[str] = mapped_column(String, nullable=False)
    # Реальные габариты одной палеты (метры). Пользователь задаёт их сам.
    pallet_length_m: Mapped[float] = mapped_column(Float, default=1.2)
    pallet_width_m: Mapped[float] = mapped_column(Float, default=0.8)
    pallet_height_m: Mapped[float] = mapped_column(Float, default=1.2)
    pallet_weight_kg: Mapped[float] = mapped_column(Float, nullable=False)
    pallet_volume_m3: Mapped[float] = mapped_column(Float, nullable=False)
    total_volume_m3: Mapped[float] = mapped_column(Float, nullable=False)
    total_weight_kg: Mapped[float] = mapped_column(Float, nullable=False)
    special_conditions: Mapped[str] = mapped_column(Text, default="")
    vehicle_id: Mapped[int | None] = mapped_column(ForeignKey("vehicles.id"), nullable=True)
    status: Mapped[str] = mapped_column(String, default="new")
    created_at: Mapped[str] = mapped_column(String, server_default=func.datetime("now"))

    vehicle: Mapped["Vehicle | None"] = relationship(back_populates="orders")
