"""Реалистичный 3D-упаковщик грузов LoadSmart.

Подход — послойная укладка (Layered Shelf Packing) с настоящими габаритами:
  * кузов = ящик L(длина, Z) × W(ширина, X) × H(высота, Y);
  * каждая палета имеет реальные размеры д×ш×в и может повернуться на 90°;
  * груз кладётся ярусами (levels) снизу вверх; высота яруса = max высота
    палет в нём, поэтому палеты разной высоты сосуществуют без потерь;
  * внутри яруса — «полки» (shelves) поперёк кузова, плотно по ширине;
  * порядок: тяжёлые/высокие/негабарит — в нижние ярусы, хрупкие — наверх;
  * нештабелируемые (oversize, no_tilt) занимают только нижний ярус;
  * считаем заполнение по объёму и массе, центр тяжести, нагрузку на оси,
    индекс устойчивости. Цель — уложить максимум, честно показать остаток.

Координаты — центры палет в метрах (система Three.js, Y — вверх).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from models import Order, Vehicle

COLORS = {
    "standard": "#3B82F6",
    "fragile": "#EF4444",
    "oversize": "#F59E0B",
}

GAP = 0.02            # технологический зазор между палетами, м (только между, не по краям)
MIN_DIM = 0.2


@dataclass
class Pallet:
    order_id: int
    cargo_type: str
    weight_kg: float
    l: float          # длина (вдоль Z по умолчанию)
    w: float          # ширина (вдоль X по умолчанию)
    h: float          # высота (Y)
    fragile: bool
    no_tilt: bool
    stackable: bool
    # позиция центра + фактическая ориентация footprint (size_x, size_z)
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    sx: float = 0.0   # габарит вдоль X после раскладки
    sz: float = 0.0   # габарит вдоль Z
    rotated: bool = False
    layer: int = 0

    @property
    def volume(self) -> float:
        return self.l * self.w * self.h


def _explode_orders(orders: list[Order]) -> list[Pallet]:
    out: list[Pallet] = []
    for o in orders:
        cond = (o.special_conditions or "").split(",")
        no_tilt = "no_tilt" in cond           # нельзя поворачивать/кантовать
        fragile = o.cargo_type == "fragile"
        stackable = o.cargo_type != "oversize"  # негабарит — только на пол
        L = max(MIN_DIM, o.pallet_length_m or 1.2)
        W = max(MIN_DIM, o.pallet_width_m or 0.8)
        H = max(MIN_DIM, o.pallet_height_m or 1.2)
        for _ in range(o.pallet_count):
            out.append(Pallet(
                order_id=o.id, cargo_type=o.cargo_type, weight_kg=o.pallet_weight_kg,
                l=L, w=W, h=H, fragile=fragile, no_tilt=no_tilt, stackable=stackable,
            ))
    return out


@dataclass
class _Column:
    """Башня на полу: footprint (x0,z0,sx,sz) и стопка палет по высоте."""
    x0: float
    z0: float
    sx: float
    sz: float
    items: list[Pallet] = field(default_factory=list)
    top: float = 0.0          # текущая высота стопки

    @property
    def base(self) -> Pallet:
        return self.items[-1]


def _fit_footprint(p: Pallet, W: float):
    """Варианты ориентации footprint (sx, sz, rotated), влезающие по ширине W.
    Узкую сторону вдоль X — первой (плотнее ряды). no_tilt запрещает поворот."""
    opts = [(p.w, p.l, False)]
    if not p.no_tilt and abs(p.w - p.l) > 1e-6:
        opts.append((p.l, p.w, True))
    opts = [o for o in opts if o[0] <= W + 1e-9]
    opts.sort(key=lambda o: o[0])
    return opts


def build_load_plan(vehicle: Vehicle, orders: list[Order]) -> dict:
    L, W, H = vehicle.length_m, vehicle.width_m, vehicle.height_m
    pallets = _explode_orders(orders)

    placed: list[Pallet] = []
    unplaced: list[Pallet] = []
    columns: list[_Column] = []

    # Порядок: негабарит и тяжёлое/высокое — первыми (на пол, в основания башен),
    # хрупкое — в самый конец, чтобы лечь на верхушки.
    order = sorted(
        pallets,
        key=lambda p: (p.fragile, not (p.cargo_type == "oversize"), -p.h, -p.weight_kg),
    )

    # курсор раскладки башен по полу: ряды вдоль Z, внутри ряда — вдоль X.
    # Зазоры только МЕЖДУ палетами, по краям кузова прижимаемся к 0.
    cursor_z = 0.0
    shelf_x = 0.0
    row_depth = 0.0
    first_in_row = True

    def can_stack_on(col: _Column, p: Pallet, sx: float, sz: float) -> bool:
        if not col.items:
            return False
        base = col.base
        if base.fragile or not base.stackable:   # на хрупкое/негабарит не ставим
            return False
        if not p.stackable:                       # негабарит не штабелируем вверх
            return False
        if abs(col.sx - sx) > 0.02 or abs(col.sz - sz) > 0.02:
            return False
        if col.top + p.h + 0.02 > H + 1e-9:
            return False
        if p.weight_kg > base.weight_kg * 1.6 + 1:  # сверху не сильно тяжелее
            return False
        return True

    def place(p: Pallet) -> bool:
        nonlocal cursor_z, shelf_x, row_depth
        opts = _fit_footprint(p, W)
        if not opts:
            return False

        # 1) штабелировать на подходящую башню (самую высокую из годных — добиваем до верха)
        best = None
        best_rot = None
        for col in columns:
            for sx, sz, rotated in opts:
                if can_stack_on(col, p, sx, sz):
                    if best is None or col.top > best.top:
                        best, best_rot = col, (sx, sz, rotated)
        if best is not None:
            sx, sz, rotated = best_rot
            p.x = best.x0 + sx / 2
            p.z = best.z0 + sz / 2
            p.y = best.top + p.h / 2
            p.sx, p.sz, p.rotated = sx, sz, rotated
            p.layer = len(best.items)
            best.items.append(p)
            best.top += p.h
            placed.append(p)
            return True

        # 2) новая башня на полу
        nonlocal first_in_row
        if p.h > H + 1e-9:
            return False

        def commit(sx, sz, rotated, x0, z0):
            nonlocal shelf_x, row_depth, first_in_row
            p.x = x0 + sx / 2
            p.z = z0 + sz / 2
            p.y = p.h / 2
            p.sx, p.sz, p.rotated = sx, sz, rotated
            p.layer = 0
            columns.append(_Column(x0=x0, z0=z0, sx=sx, sz=sz, items=[p], top=p.h))
            placed.append(p)
            shelf_x = x0 + sx + GAP
            row_depth = max(row_depth, sz)
            first_in_row = False

        # 2a) пытаемся вписать в текущий ряд (узкой стороной — приоритет)
        x_start = shelf_x if not first_in_row else 0.0
        for sx, sz, rotated in opts:
            if x_start + sx <= W + 1e-9 and cursor_z + sz <= L + 1e-9:
                commit(sx, sz, rotated, x_start, cursor_z)
                return True

        # 2b) открываем новый ряд вдоль длины
        cursor_z += row_depth + (GAP if row_depth else 0.0)
        shelf_x = 0.0
        row_depth = 0.0
        first_in_row = True
        for sx, sz, rotated in opts:
            if sx <= W + 1e-9 and cursor_z + sz <= L + 1e-9:
                commit(sx, sz, rotated, 0.0, cursor_z)
                return True
        return False

    for p in order:
        if not place(p):
            unplaced.append(p)

    return _assemble(vehicle, placed, unplaced)


def _empty_plan(vehicle: Vehicle) -> dict:
    return _assemble(vehicle, [], [])


def _assemble(vehicle: Vehicle, placed: list[Pallet], unplaced: list[Pallet]) -> dict:
    L, W, H = vehicle.length_m, vehicle.width_m, vehicle.height_m
    used_volume = sum(p.volume for p in placed)
    total_weight = sum(p.weight_kg for p in placed)
    fill_pct = round(used_volume / vehicle.volume_m3 * 100) if vehicle.volume_m3 else 0
    weight_pct = round(total_weight / vehicle.max_weight_kg * 100) if vehicle.max_weight_kg else 0

    if total_weight > 0:
        cx = sum(p.x * p.weight_kg for p in placed) / total_weight
        cy = sum(p.y * p.weight_kg for p in placed) / total_weight
        cz = sum(p.z * p.weight_kg for p in placed) / total_weight
    else:
        cx = cy = cz = 0.0

    if total_weight > 0 and L > 0:
        rear_share = max(0.0, min(1.0, cz / L))
        front_share = 1 - rear_share
    else:
        rear_share = front_share = 0.5
    front_axle = round(total_weight * front_share)
    rear_axle = round(total_weight * rear_share)

    h_factor = 1 - min(cy / (H or 1), 1)
    x_factor = 1 - min(abs(cx - W / 2) / (W / 2 or 1), 1)
    z_factor = 1 - min(abs(cz - L / 2) / (L / 2 or 1), 1)
    stability = round((0.5 * h_factor + 0.3 * x_factor + 0.2 * z_factor) * 100)

    pallets_out = [
        {
            "id": i + 1,
            "order_id": p.order_id,
            "cargo_type": p.cargo_type,
            "weight_kg": round(p.weight_kg, 1),
            "volume_m3": round(p.volume, 3),
            "width": round(p.sx or p.w, 3),
            "depth": round(p.sz or p.l, 3),
            "height": round(p.h, 3),
            "x": round(p.x, 3),
            "y": round(p.y, 3),
            "z": round(p.z, 3),
            "layer": p.layer,
            "rotated": p.rotated,
            "fragile": p.fragile,
            "color": COLORS.get(p.cargo_type, COLORS["standard"]),
        }
        for i, p in enumerate(placed)
    ]

    return {
        "vehicle": {
            "name": vehicle.name, "type": vehicle.type,
            "length_m": L, "width_m": W, "height_m": H,
            "max_weight_kg": vehicle.max_weight_kg, "volume_m3": vehicle.volume_m3,
            "axles": getattr(vehicle, "axles", 2) or 2,
        },
        "pallets": pallets_out,
        "fill_pct": fill_pct,
        "weight_pct": weight_pct,
        "used_volume_m3": round(used_volume, 2),
        "total_weight_kg": round(total_weight, 1),
        "pallet_count": len(placed),
        "unplaced_count": len(unplaced),
        "center_of_gravity": {"x": round(cx, 2), "y": round(cy, 2), "z": round(cz, 2)},
        "axle_load": {
            "front_kg": front_axle, "rear_kg": rear_axle,
            "front_pct": round(front_share * 100), "rear_pct": round(rear_share * 100),
        },
        "stability_pct": stability,
        "layers": (max((p.layer for p in placed), default=-1) + 1),
    }


# ---------- агрегаты для списков/аналитики ----------
def vehicle_used_volume(vehicle: Vehicle) -> float:
    return sum(o.total_volume_m3 for o in vehicle.orders if o.status != "cancelled")


def vehicle_used_weight(vehicle: Vehicle) -> float:
    return sum(o.total_weight_kg for o in vehicle.orders if o.status != "cancelled")


def vehicle_load_pct(vehicle: Vehicle) -> int:
    if not vehicle.volume_m3:
        return 0
    return round(vehicle_used_volume(vehicle) / vehicle.volume_m3 * 100)


def vehicle_weight_pct(vehicle: Vehicle) -> int:
    if not vehicle.max_weight_kg:
        return 0
    return round(vehicle_used_weight(vehicle) / vehicle.max_weight_kg * 100)
